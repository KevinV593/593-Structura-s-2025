#pragma once
#include "VistaConsola.h"

class Controlador {
private:
    VistaConsola vista;

public:
    void ejecutar();
};
