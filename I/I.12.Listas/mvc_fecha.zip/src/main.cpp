#include "Controlador.h"

int main() {
    Controlador c;
    c.ejecutar();
    return 0;
}
